package com.capgemini.ams.ui;


import java.io.File;
import java.io.FileWriter;

import au.com.bytecode.opencsv.CSVWriter;
import au.com.bytecode.opencsv.bean.ColumnPositionMappingStrategy;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.ams.bean.AssetAllocationBean;
import com.capgemini.ams.bean.AssetDetailsBean;
import com.capgemini.ams.bean.UserMasterBean;
import com.capgemini.ams.exception.AMSException;
import com.capgemini.ams.service.AssetServiceAdmin;
import com.capgemini.ams.service.AssetServiceUser;
import com.capgemini.ams.service.IAssetServiceAdmin;
import com.capgemini.ams.service.IAssetServiceUser;

public class AssetClient {
	
	static IAssetServiceUser serviceUser=null;
	static IAssetServiceAdmin serviceAdmin=null;
	static Scanner scanner = new Scanner(System.in);
	
	public static void main(String[] args) throws AMSException, IOException {

		serviceUser=new AssetServiceUser();
		int status=0;
		//Login of the user/admin
		do{
		System.out.println("*****************************************");
		System.out.println("\tAsset Management System");
		System.out.println("*****************************************");
		System.out.println();
		System.out.println("Enter UserId");
		String userId=scanner.next();
		while (!serviceUser.isValidUserId(userId)) {
			System.err.println("Should contain only numbers");
			userId = scanner.next();
		} 
		System.out.println("Enter Password");
		String password=scanner.next();
		
		serviceUser=new AssetServiceUser();
		UserMasterBean userMaster=new UserMasterBean(userId,password);
		status=serviceUser.authenticateUser(userMaster);
		if(status==1){
			System.out.println();
			System.out.println();
			System.out.println("User Successfully Loged In");
			AssetClient.Manager();
		}else if(status==2){
			System.out.println("Admin Successfully Loged In");
			AssetClient.Admin();
		}else if(status==0){
			System.out.println("Please Check UserID and Password ");
			System.out.println();
			System.out.println();
		}
	}while(status==0);
		
			
	}
	
	
	public static void Manager() throws AMSException{
		
		int choice=0;
		do{
			//Menu of Manager
			System.out.println();
			System.out.println();
			System.out.println("**************Welcome Manager**************");
			System.out.println("1. Raise a Request for asset");
			System.out.println("2. Status of Request");
			System.out.println("3. Exit");
			System.out.println("Enter Your option");
			choice=scanner.nextInt();
			switch (choice) {
				case 1:
						//Raise a request for asset
						//Display the asset id and asset name
						serviceUser=new AssetServiceUser();
						HashMap<Integer, String> assetMap=serviceUser.displayAssetDetails();
			
						System.out.println("------------List of Assets--------------");
						for(HashMap.Entry<Integer, String> entry:assetMap.entrySet()){    
			 
							System.out.println(entry.getKey()+"  "+entry.getValue());
						}
				
				
						//The asset Id and employee Id is taken from the manager to raise a request
						while(true){
						try{
						System.out.println();
						System.out.println("Enter the Asset Id");
						
						int assetId=scanner.nextInt();
						while (!serviceUser.isValidAssetId(assetId)) {
							System.err.println("Should contain only 4 digit number");
							assetId = scanner.nextInt();
						} 
						System.out.println("asd");
						//To check whether the entered assetId is valid or not
						int validateAssetId=serviceUser.checkAssetId(assetId);
						if(validateAssetId==1){
							System.out.println("Enter the Employee Id");
							int employeeId=scanner.nextInt();
							/*while (!serviceUser.isValidEmployeeId(employeeId)) {
								System.err.println("Should contain only 5 digit number");
								employeeId = scanner.nextInt();
							}*/ 
							//To check whether the entered employeeId is valid or not
							int validateEmployeeId=serviceUser.checkEmployeeId(employeeId);
							System.out.println("qwerty");
							AssetAllocationBean assetAllocation=new AssetAllocationBean(assetId, employeeId);
							if(validateEmployeeId==1){
									int allocationId=serviceUser.raiseRequest(assetAllocation);
									System.out.println("The Request has been raised with Requisition Id: "+allocationId);
							}
							else{
								System.out.println("Invalid EmployeeId");
								break;
							}
						}else{
							System.out.println("Invalid AssetId");
						}
						}catch(InputMismatchException e){
							scanner.next();
							System.err.println("Please enter a number");
							continue;
						}
					}
						break;

				case 2:
						//Get the status of the requisition Id
					int requisitionId=0;
					int validateRequsitionId=0;
				p3:	do{
						System.out.println("Enter the Requisition Id");
					try{
						requisitionId= scanner.nextInt();
						while (!serviceUser.isValidRequisitionId(requisitionId)) {
							System.err.println("Should contain only 5 digit number");
							requisitionId = scanner.nextInt();
						}
						validateRequsitionId=serviceUser.checkRequisitionId(requisitionId);
						if(validateRequsitionId==1){
						serviceUser=new AssetServiceUser();
						String statusOfRequisitionId=serviceUser.viewStatus(requisitionId);
						System.out.println("The Status for Requisition Id : "+requisitionId+" is: "+ statusOfRequisitionId);
						}else{
							System.out.println("Invalid RequisitionId");
						}
					}catch(InputMismatchException e){
						scanner.next();
						System.err.println("Please enter a number");
						continue p3;
					}
					}while(validateRequsitionId==1);
						break;
				case 3:
						System.out.println("You have logged out successfully");
						System.exit(0);
						break;

				default:
						System.out.println("wrong choice");
						break;
				}
		}while(choice!=3);
		
		
	}
	
	public static void Admin() throws AMSException, IOException{
		
		int option=0;
		int choice1=0;
		serviceAdmin=new AssetServiceAdmin();
		System.out.println();
		System.out.println();
		do{
			//Menu of admin
		System.out.println("***************Welcome Admin********************");
		System.out.println("1. INSERT/MODIFY Asset Details");
		System.out.println("2. Assign the Asset");
		System.out.println("3. Display Allocation Details");
		System.out.println("4. Export to Excel Sheet");
		System.out.println("5. Exit");
		System.out.println("Enter Your option");
		choice1=scanner.nextInt();
		
		switch (choice1) {
		case 1:
			do{
			System.out.println();
			System.out.println("1. Insert Asset Details");
			System.out.println("2. Modify Asset Details");
			System.out.println("3. Exit");
			System.out.println("Enter Your option");
			option=scanner.nextInt();
			int status=0;
			//Insert new Asset Details
					switch(option){
					case 1:
							System.out.println("Enter Asset Name");
							String a=scanner.nextLine();
							String assetName=scanner.nextLine();
							System.out.println("Enter Asset Description");
							String assetDescription=scanner.nextLine();
							System.out.println("Enter Asset Quantity");
							int quantity=scanner.nextInt();
							do{
							System.out.println("Enter Status");
							System.out.println("1. Available");
							System.out.println("2. Not Available");
							System.out.println("Enter your option:");
							status=scanner.nextInt();
							if(status==1||status==2){
				
							AssetDetailsBean assetDetails=new AssetDetailsBean(assetName, assetDescription, quantity);
							//pass the information taken from user to the assetServiceAdmin class to store data in the database
							int insertStatus=serviceAdmin.addAssetDetails(assetDetails,status);
			  				System.out.println(insertStatus+" Asset added");
			  				
							}
							else{
								System.out.println("Invalid option");
								break;
							}
							}while(status==1||status==2);
							break;
					case 2:
							serviceAdmin=new AssetServiceAdmin();
							ArrayList<AssetDetailsBean> assetList=serviceAdmin.assetInInventory();
							System.out.println();
							System.out.println("***************Asset Details*****************");
							System.out.println();
							System.out.println("Asset ID:\t Asset Name:\t Asset Description:\t Asset Quantity:\t Asset Status:");
						
							for (AssetDetailsBean assetDetails : assetList)
							{
								System.out.println(assetDetails.getAssetId()+"\t\t "+assetDetails.getAssetName()+"\t\t "+ assetDetails.getAssetDescription()+"\t\t "+ assetDetails.getQuantity()+"\t "+ assetDetails.getStatus());
							}
						
						
						    int columnToBeUpdated=0;
							System.out.println("Enter the Asset ID you want to update");
							int assetId=scanner.nextInt();
							int validateAssetId=serviceUser.checkAssetId(assetId);
							if(validateAssetId==1){
							do{
							System.out.println("1. Update Asset Name");
							System.out.println("2. Update Asset Description");
							System.out.println("3. Update Quantity");
							System.out.println("4. Update Status");
							System.out.println("5. Exit");
							System.out.println("Enter your choice");
							columnToBeUpdated=scanner.nextInt();
							switch (columnToBeUpdated) {
								case 1:
									System.out.println("Enter new Asset Name");
									String dummy1=scanner.nextLine();
									String newAssetName= scanner.nextLine();
									
									AssetDetailsBean assetNameDetails= new AssetDetailsBean(assetId, newAssetName);
									int assetNameUpdateStatus=serviceAdmin.updateAssetName(assetNameDetails);
									if(assetNameUpdateStatus==1){
										System.out.println("Asset Name successfully Updated");
									}else{
										System.out.println("Update Declined");
									}
									
									
									break;
								case 2:
									System.out.println("Enter new Asset Description");
									String dummy2=scanner.nextLine();
									String newAssetDescription= scanner.nextLine();
									AssetDetailsBean assetDescriptionDetails= new AssetDetailsBean(newAssetDescription,assetId);
									int assetDescriptionUpdateStatus=serviceAdmin.updateAssetDescription(assetDescriptionDetails);
									if(assetDescriptionUpdateStatus==1){
										System.out.println("Asset Description successfully Updated");
									}else{
										System.out.println("Update Declined");
									}
									
				
									break;
								case 3:
									System.out.println("Enter new Asset Quantity");
									int newAssetQuantity= scanner.nextInt();
									
									AssetDetailsBean assetQuantityDetails= new AssetDetailsBean(assetId,newAssetQuantity);
									int assetQuantityUpdateStatus=serviceAdmin.updateAssetQuantity(assetQuantityDetails);
									if(assetQuantityUpdateStatus==1){
										System.out.println("Asset Quantity successfully Updated");
									}else{
										System.out.println("Update Declined");
									}
									
									break;
								case 4:
									System.out.println("Enter new Asset Quantity");
									System.out.println("1. Available");
									System.out.println("2. Not Available");
									System.out.println("Enter your option:");
									int newAssetStatus= scanner.nextInt();
									
									if(newAssetStatus==1||newAssetStatus==2){
										
										
										int assetStatusUpdateStatus=serviceAdmin.updateAssetQuantity(assetId,newAssetStatus);
										if(assetStatusUpdateStatus==1){
											System.out.println("Asset Status successfully Updated");
										}else{
											System.out.println("Update Declined");
										}
										}
										else{
											System.out.println("Invalid option");
											break;
										}
							
	
											break;
									case 5:
											break;
									default:
											System.out.println("wrong choice");
											break;
										}
							}while(columnToBeUpdated!=5);
									}else{
								System.out.println("Invalid AssetId");
							}
							break;
					default:
						System.out.println("wrong choice");
							break;
					}
			}while(option!=3);
				break;	

		case 2:
			serviceAdmin=new AssetServiceAdmin();
			ArrayList<AssetAllocationBean> unapprovedList=serviceAdmin.displayUnapprovedAssets();
			System.out.println();
			System.out.println("***************Unapproved Assets*****************");
			System.out.println();
			System.out.println("Allocation Id:\t Asset ID:\t Employee No.\t Allocation Date\t Release Date");
					
					for (AssetAllocationBean assetAllocation : unapprovedList)
					{
						System.out.println(assetAllocation.getAllocationId()+"\t\t "+assetAllocation.getAssetId()+"\t\t "+ assetAllocation.getEmpNo()+"\t\t "+ assetAllocation.getAllocationDate()+"\t "+ assetAllocation.getReleaseDate());
					}
			int assignOption=0;		
			do{
			System.out.println("1. You want to check inventory");
			System.out.println("2. Approve pending request");
			System.out.println("3. Exit");
			System.out.println("Enter your choice");
			assignOption=scanner.nextInt();
			switch(assignOption){
		
					case 1:
							serviceAdmin=new AssetServiceAdmin();
							ArrayList<AssetDetailsBean> assetList=serviceAdmin.assetInInventory();
							System.out.println();
							System.out.println("***************Asset Details*****************");
							System.out.println();
							System.out.println("Asset ID:\t Asset Name:\t Asset Description:\t Asset Quantity:\t Asset Status:");
			
							for (AssetDetailsBean assetDetails : assetList)
							{
								System.out.println(assetDetails.getAssetId()+"\t\t "+assetDetails.getAssetName()+"\t\t "+ assetDetails.getAssetDescription()+"\t\t "+ assetDetails.getQuantity()+"\t "+ assetDetails.getStatus());
							}
							break;
					case 2:
							System.out.println("Enter the Requisition ID to be approved");
							int requisitionId=scanner.nextInt();
							AssetAllocationBean assetAllocation  = new AssetAllocationBean();
							assetAllocation.setAllocationId(requisitionId);
							int approveStatus=serviceAdmin.approveRequest(assetAllocation);
							if(approveStatus==1){
								System.out.println("Request Approved Successfully");
							}
							else{
								System.out.println("Invalid allocation ID");
							}
							break;
					case 3:
						break;
					default:
							System.out.println("You have entered a invalid choice");
							break;
			}}while(assignOption!=3);
			 
			break;
		case 3:
				int choiceOfAllocationDetails=0;
				AssetAllocationBean assetAllocationBean=new AssetAllocationBean();
				do{
				System.out.println("******Allocation Details******");
				System.out.println("1. Allocated Assets");
				System.out.println("2. Unallocted Assets");
				System.out.println("3. Exit");
				System.out.println("Enter your choice");
				choiceOfAllocationDetails=scanner.nextInt();
				switch(choiceOfAllocationDetails){
				
				case 1:
					
					serviceAdmin=new AssetServiceAdmin();
					ArrayList<AssetAllocationBean> allocatedList=serviceAdmin.displayAllocatedAssets();
					System.out.println();
					System.out.println("***************Allocated Assets*****************");
					System.out.println();
					System.out.println("Allocation Id:\t Asset ID:\t Employee No.\t Allocation Date\t Release Date");
					
					for (AssetAllocationBean assetAllocation : allocatedList)
					{
						System.out.println(assetAllocation.getAllocationId()+"\t\t "+assetAllocation.getAssetId()+"\t\t "+ assetAllocation.getEmpNo()+"\t\t "+ assetAllocation.getAllocationDate()+"\t "+ assetAllocation.getReleaseDate());
					}
					
					break;
				case 2:
					serviceAdmin=new AssetServiceAdmin();
					ArrayList<AssetAllocationBean> unallocatedList=serviceAdmin.displayUnallocatedAssets();
					System.out.println();
					System.out.println("***************Unallocated Assets*****************");
					System.out.println();
					System.out.println("Allocation Id:\t Asset ID:\t Employee No.\t Allocation Date\t Release Date");
					
					for (AssetAllocationBean assetAllocation : unallocatedList)
					{
						System.out.println(assetAllocation.getAllocationId()+"\t\t "+assetAllocation.getAssetId()+"\t\t "+ assetAllocation.getEmpNo()+"\t\t "+ assetAllocation.getAllocationDate()+"\t "+ assetAllocation.getReleaseDate());
					}
					
					break;
				case 3:
					break;
				default:
					System.out.println("Invalid option");
					break;
				}
				}while(choiceOfAllocationDetails!=3);
			break;

		case 4:
			 	
			break;
		case 5:
			System.out.println("You have logged out successfully");
			System.exit(0);
			break;

		default:
			System.out.println("wrong choice");
			break;
		}
		}while(choice1!=5);
	}

}

