/***********************************Author Name:Manoj M Maragiri Emp Id : 155246******************************************/
/* The AssetClient contains the login of Admin and user. 
 * It contains the operations that are performed by the Admin or User.
 *The input from the User or admin taken in this AssetClient class */
package com.capgemini.ams.ui;

import java.io.File;
import java.io.FileWriter;

import au.com.bytecode.opencsv.CSVWriter;
import au.com.bytecode.opencsv.bean.ColumnPositionMappingStrategy;

import org.apache.log4j.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.ams.bean.AssetAllocationBean;
import com.capgemini.ams.bean.AssetDetailsBean;
import com.capgemini.ams.bean.UserMasterBean;
import com.capgemini.ams.exception.AMSException;
import com.capgemini.ams.service.AssetServiceAdmin;
import com.capgemini.ams.service.AssetServiceUser;
import com.capgemini.ams.service.IAssetServiceAdmin;
import com.capgemini.ams.service.IAssetServiceUser;

public class AssetClient {

	static IAssetServiceUser serviceUser = null;
	static IAssetServiceAdmin serviceAdmin = null;
	static Scanner scanner = new Scanner(System.in);
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) throws AMSException, IOException {

		serviceUser = new AssetServiceUser();
		int status = 0;
		// Login of the user/admin
		do {
			System.out.println("***************************************");
			System.out.println("\tAsset Management System");
			System.out.println("***************************************");
			System.out.println();
			System.out.println("Enter UserId");
			String userId = scanner.next();
			while (!serviceUser.isValidUserId(userId)) {
				System.err.println("Should contain only numbers");
				userId = scanner.next();
			}
			System.out
					.println("Enter Password\t(Password can contain uppercase alphabets,lowercase alphabets,numbers(0-9), and special characters like & ! @ # $ _)");
			String dummyVariable0 = scanner.nextLine();
			String password = scanner.nextLine();
			while (!serviceUser.isValidPassword(password)) {
				System.err.println("Should not contain spaces");
				password = scanner.next();
			}
			UserMasterBean userMaster = new UserMasterBean(userId,
					password);
			status = serviceUser.authenticateUser(userMaster);
			if (status == 1) {
				System.out.println();
				logger.info("User Logged In successfully");
				System.out.println("User Successfully Loged In");
				AssetClient.Manager();
			} else if (status == 2) {
				System.out.println();
				logger.info("Admin Logged In successfully");
				System.out.println("Admin Successfully Loged In");
				AssetClient.Admin();
			} else if (status == 0) {
				System.out.println();
				logger.info("Incorrect UserId and Password");
				System.out.println("Please Check UserID and Password ");
				System.out.println();
			}
		} while (status == 0);
	}

	/*****************************************************************************************************************************************/

	// Manager method

	/*****************************************************************************************************************************************/

	public static void Manager() throws AMSException {

		int managerOption = 0;
		do {
			// Menu of Manager
			System.out.println();
			System.out.println("*****************************************");
			System.out.println("\tWelcome Manager");
			System.out.println("*****************************************");
			System.out.println("1. Raise a Request for asset");
			System.out.println("2. Status of Request");
			System.out.println("3. Exit");
			System.out.println("Enter Your option");
			managerOption = AssetClient.inputOptions();
			switch (managerOption) {
			case 1:
				// Raise a request for asset
				// Display the asset id and asset name
				serviceUser = new AssetServiceUser();
				HashMap<Integer, String> assetMap = serviceUser
						.displayAssetDetails();

				System.out.println("---------------------------------------");
				System.out.println("\tList of Assets");
				System.out.println("---------------------------------------");
				for (HashMap.Entry<Integer, String> entry : assetMap.entrySet()) {

					System.out
							.println(entry.getKey() + "  " + entry.getValue());
				}
				// The asset Id and employee Id is taken from the manager to
				// raise a request
				AssetClient.inputRequiredAssetId();
				break;
			case 2:
				// Get the status of the requisition Id
				System.out.println("Enter the Requisition Id");
				int requisitionId = AssetClient.inputRequisitionId();
				int validateRequsitionId = serviceUser
						.checkRequisitionId(requisitionId);
				if (validateRequsitionId == 1) {
					AssetAllocationBean assetAllocation = new AssetAllocationBean();
					assetAllocation.setAllocationId(requisitionId);
					String statusOfRequisitionId = serviceUser
							.viewStatus(assetAllocation);
					logger.info("The Status for Requisition Id : "
							+ requisitionId + " is: " + statusOfRequisitionId);
					System.out.println("The Status for Requisition Id : "
							+ requisitionId + " is: " + statusOfRequisitionId);
				} else {
					System.out.println("Invalid RequisitionId");
				}
				break;
			case 3:// user logs out
				logger.info("User Logged Out Successfully");
				System.out.println("You have logged out successfully");
				System.exit(0);
				break;

			default:
				// System.err.println("INVALID OPTION ENTRY");
				break;
			}
		} while (managerOption != 3);
	}

	/*****************************************************************************************************************************************/

	// Admin method

	/*****************************************************************************************************************************************/

	public static void Admin() throws AMSException, IOException {

		int adminOption = 0;
		serviceAdmin = new AssetServiceAdmin();
		System.out.println();
		System.out.println();
		do {
			// Menu of admin
			System.out.println("*****************************************");
			System.out.println("\tWelcome Admin");
			System.out.println("*****************************************");
			System.out.println("1. INSERT/MODIFY Asset Details");
			System.out.println("2. Assign the Asset");
			System.out.println("3. Display Allocation Details");
			System.out.println("4. Export to Excel Sheet");
			System.out.println("5. Exit");
			System.out.println("Enter Your option");
			adminOption = AssetClient.inputOptions();

			// INSERT/MODIFY Asset Details Menu
			switch (adminOption) {
			case 1:
				int assetDetailsOption = 0;
				do {
					System.out.println();
					System.out.println("1. Insert Asset Details");
					System.out.println("2. Modify Asset Details");
					System.out.println("3. Exit");
					System.out.println("Enter Your option");
					assetDetailsOption = AssetClient.inputOptions();

					int statusOption = 0;
					// Insert new Asset Details
					switch (assetDetailsOption) {
					case 1:
						System.out.println("Enter Asset Name");
						String dummyVariable1 = scanner.nextLine();
						String assetName = scanner.nextLine();
						while (!serviceAdmin.isValidString(assetName)) {
							System.err
									.println("Should contain a minimum of 5 Characters");
							assetName = scanner.next();
						}
						System.out.println("Enter Asset Description");
						String assetDescription = scanner.nextLine();
						while (!serviceAdmin.isValidString(assetDescription)) {
							System.err
									.println("Should contain a minimum of 5 Characters");
							assetDescription = scanner.next();
						}
						System.out.println("Enter Asset Quantity");
						int quantity = AssetClient.inputQuantity();

						System.out.println("Enter Status");
						System.out.println("1. Available");
						System.out.println("2. Not Available");
						System.out.println("Enter your option:");
						statusOption = AssetClient.inputOptions();
						if (statusOption == 1 || statusOption == 2) {

							AssetDetailsBean assetDetails = new AssetDetailsBean();
							assetDetails.setAssetName(assetName);
							assetDetails.setAssetDescription(assetDescription);
							assetDetails.setQuantity(quantity);
							// pass the information taken from user to the
							// assetServiceAdmin class to store data in the
							// database
							int insertStatus = serviceAdmin.addAssetDetails(
									assetDetails, statusOption);
							logger.info("1 Asset added");
							System.out.println(insertStatus + " Asset added");
						} else {
							System.out.println("Invalid option");
						}
						break;
					case 2:
						// Display Asset details
						serviceAdmin = new AssetServiceAdmin();
						ArrayList<AssetDetailsBean> assetList = serviceAdmin
								.assetInInventory();
						System.out.println();
						System.out
								.println("*************************************");
						System.out.println("\tAsset Details");
						System.out
								.println("*************************************");
						System.out.println();

						for (AssetDetailsBean assetDetails : assetList) {
							System.out.println("Asset ID: "
									+ assetDetails.getAssetId()
									+ "\tAsset Name: "
									+ assetDetails.getAssetName()
									+ "\tAsset Description: "
									+ assetDetails.getAssetDescription()
									+ "\tAsset Quantity: "
									+ assetDetails.getQuantity()
									+ "\tAsset Status: "
									+ assetDetails.getStatus());
						}
						// Menu to update asset details
						int columnToBeUpdated = 0;
						System.out
								.println("Enter the Asset ID you want to update");
						int assetId = AssetClient.inputAssetIdToUpdate();
						int validateAssetId = serviceUser.checkAssetId(assetId);
						if (validateAssetId == 1) {
							do {
								System.out.println("1. Update Asset Name");
								System.out
										.println("2. Update Asset Description");
								System.out.println("3. Update Quantity");
								System.out.println("4. Update Status");
								System.out.println("5. Exit");
								System.out.println("Enter your choice");
								columnToBeUpdated = AssetClient.inputOptions();
								switch (columnToBeUpdated) {
								case 1:
									// Update Asset name
									System.out.println("Enter new Asset Name");
									String dummyVariable2 = scanner.nextLine();
									String newAssetName = scanner.nextLine();
									while (!serviceAdmin
											.isValidString(newAssetName)) {
										System.err
												.println("Should contain a minimum of 5 Characters");
										newAssetName = scanner.next();
									}
									AssetDetailsBean assetNameDetails = new AssetDetailsBean();
									assetNameDetails.setAssetId(assetId);
									assetNameDetails.setAssetName(newAssetName);
									int assetNameUpdateStatus = serviceAdmin
											.updateAssetName(assetNameDetails);
									if (assetNameUpdateStatus == 1) {
										logger.info("Asset Name successfully Updated");
										System.out
												.println("Asset Name successfully Updated");
									} else {
										logger.info("Update Declined");
										System.out.println("Update Declined");
									}
									break;
								case 2:
									// Update Asset description
									System.out
											.println("Enter new Asset Description");
									String dummyVariable3 = scanner.nextLine();
									String newAssetDescription = scanner
											.nextLine();
									while (!serviceAdmin
											.isValidString(newAssetDescription)) {
										System.err
												.println("Should contain a minimum of 5 Characters");
										newAssetDescription = scanner.next();
									}

									AssetDetailsBean assetDescriptionDetails = new AssetDetailsBean();
									assetDescriptionDetails.setAssetId(assetId);
									assetDescriptionDetails
											.setAssetDescription(newAssetDescription);
									int assetDescriptionUpdateStatus = serviceAdmin
											.updateAssetDescription(assetDescriptionDetails);
									if (assetDescriptionUpdateStatus == 1) {
										logger.info("Asset Description successfully Updated");
										System.out
												.println("Asset Description successfully Updated");
									} else {
										logger.info("Update Declined");
										System.out.println("Update Declined");
									}
									break;
								case 3:
									// Update Asset Quantity
									System.out
											.println("Enter new Asset Quantity");
									int newAssetQuantity = AssetClient
											.inputQuantity();
									AssetDetailsBean assetQuantityDetails = new AssetDetailsBean();
									assetQuantityDetails.setAssetId(assetId);
									assetQuantityDetails
											.setQuantity(newAssetQuantity);
									int assetQuantityUpdateStatus = serviceAdmin
											.updateAssetQuantity(assetQuantityDetails);
									if (assetQuantityUpdateStatus == 1) {
										logger.info("Asset Quantity successfully Updated");
										System.out
												.println("Asset Quantity successfully Updated");
									} else {
										logger.info("Update Declined");
										System.out.println("Update Declined");
									}
									break;
								case 4:
									// Update Asset Status
									System.out
											.println("Enter new Asset Status");
									System.out.println("1. Available");
									System.out.println("2. Not Available");
									System.out.println("Enter your option:");
									int newAssetStatus = AssetClient
											.inputOptions();

									if (newAssetStatus == 1
											|| newAssetStatus == 2) {

										int assetStatusUpdateStatus = serviceAdmin
												.updateAssetQuantity(assetId,
														newAssetStatus);
										if (assetStatusUpdateStatus == 1) {
											logger.info("Asset Status successfully Updated");
											System.out
													.println("Asset Status successfully Updated");
										} else {
											logger.info("Update Declined");
											System.out
													.println("Update Declined");
										}
									} else {
										System.out.println("Invalid option");
										break;
									}
									break;
								case 5:
									break;
								default:
									System.err.println("INVALID OPTION ENTRY");
									break;
								}
							} while (columnToBeUpdated != 5);
						} else {
							logger.info("Invalid AssetId");
							System.out.println("Invalid AssetId");
						}
						break;
					default:
						System.err.println("INVALID OPTION ENTRY");
						break;
					}
				} while (assetDetailsOption != 3);
				break;

			case 2:
				// display pending requests
				serviceAdmin = new AssetServiceAdmin();
				ArrayList<AssetAllocationBean> unapprovedList = serviceAdmin
						.displayUnapprovedAssets();
				System.out.println();
				System.out
						.println("***************Unapproved Assets*****************");
				System.out.println();
				System.out
						.println("Allocation Id:\t Asset ID:\t Employee No.\t Allocation Date\t Release Date");

				for (AssetAllocationBean assetAllocation : unapprovedList) {
					System.out.println(assetAllocation.getAllocationId()
							+ "\t\t " + assetAllocation.getAssetId() + "\t\t "
							+ assetAllocation.getEmpNo() + "\t\t "
							+ assetAllocation.getAllocationDate() + "\t "
							+ assetAllocation.getReleaseDate());
				}
				// Approve pending requests
				int assignOption = 0;
				do {
					System.out.println("1. You want to check inventory");
					System.out.println("2. Approve pending request");
					System.out.println("3. Exit");
					System.out.println("Enter your choice");
					assignOption = AssetClient.inputOptions();
					switch (assignOption) {

					case 1:
						// display inventory
						serviceAdmin = new AssetServiceAdmin();
						ArrayList<AssetDetailsBean> assetList = serviceAdmin
								.assetInInventory();
						System.out.println();
						System.out
								.println("***************Asset Details*****************");
						System.out.println();
						System.out
								.println("Asset ID:\t Asset Name:\t Asset Description:\t Asset Quantity:\t Asset Status:");

						for (AssetDetailsBean assetDetails : assetList) {
							System.out.println(assetDetails.getAssetId()
									+ "\t\t " + assetDetails.getAssetName()
									+ "\t "
									+ assetDetails.getAssetDescription()
									+ "\t\t " + assetDetails.getQuantity()
									+ "\t\t\t " + assetDetails.getStatus());
						}
						break;
					case 2:
						// take requisition id and approve request
						System.out
								.println("Enter the Requisition ID to be approved");
						int requisitionId = AssetClient.inputRequisitionId();
						AssetAllocationBean assetAllocation = new AssetAllocationBean();
						assetAllocation.setAllocationId(requisitionId);
						int approveStatus = serviceAdmin
								.approveRequest(assetAllocation);

						if (approveStatus == 1) {
							logger.info("Request Approved Successfully");
							System.out.println("Request Approved Successfully");
						} else {
							logger.info("Invalid allocation ID");
							System.out.println("Invalid allocation ID");
						}
						break;
					case 3:
						break;
					default:
						System.err.println("INVALID OPTION ENTRY");
						break;
					}
				} while (assignOption != 3);
				break;
			case 3:
				int choiceOfAllocationDetails = 0;
				AssetAllocationBean assetAllocationBean = new AssetAllocationBean();
				do {
					System.out.println("******Allocation Details******");
					System.out.println("1. Allocated Assets");
					System.out.println("2. Unallocted Assets");
					System.out.println("3. Exit");
					System.out.println("Enter your choice");
					choiceOfAllocationDetails = AssetClient.inputOptions();
					switch (choiceOfAllocationDetails) {

					case 1:
						// display allocated assets
						serviceAdmin = new AssetServiceAdmin();
						ArrayList<AssetAllocationBean> allocatedList = serviceAdmin
								.displayAllocatedAssets();
						System.out.println();
						System.out
								.println("***************Allocated Assets*****************");
						System.out.println();
						System.out
								.println("Allocation Id:\t Asset ID:\t Employee No.\t Allocation Date\t Release Date");

						for (AssetAllocationBean assetAllocation : allocatedList) {
							System.out.println(assetAllocation
									.getAllocationId()
									+ "\t\t "
									+ assetAllocation.getAssetId()
									+ "\t\t "
									+ assetAllocation.getEmpNo()
									+ "\t\t "
									+ assetAllocation.getAllocationDate()
									+ "\t " + assetAllocation.getReleaseDate());
						}
						break;
					case 2:
						// display unallocated assets
						serviceAdmin = new AssetServiceAdmin();
						ArrayList<AssetAllocationBean> unallocatedList = serviceAdmin
								.displayUnallocatedAssets();
						System.out.println();
						System.out
								.println("***************Unallocated Assets*****************");
						System.out.println();
						System.out
								.println("Allocation Id:\t Asset ID:\t Employee No.\t Allocation Date\t Release Date");

						for (AssetAllocationBean assetAllocation : unallocatedList) {
							System.out.println(assetAllocation
									.getAllocationId()
									+ "\t\t "
									+ assetAllocation.getAssetId()
									+ "\t\t "
									+ assetAllocation.getEmpNo()
									+ "\t\t "
									+ assetAllocation.getAllocationDate()
									+ "\t " + assetAllocation.getReleaseDate());
						}

						break;
					case 3:
						break;
					default:
						System.err.println("INVALID OPTION ENTRY");
						break;
					}
				} while (choiceOfAllocationDetails != 3);
				break;

			case 4:

				break;
			case 5:
				logger.info("Admin Logged out successfully");
				System.out.println("You have logged out successfully");
				System.exit(0);
				break;

			default:
				System.err.println("INVALID OPTION ENTRY\n");
				break;
			}
		} while (adminOption != 5);
	}

	/****************************************************************************************************************************************/

	/****************************************************************************************************************************************/
	// take assetid to make request
	public static void inputRequiredAssetId() {

		try {

			System.out.println("Enter the Asset Id");
			int assetId = scanner.nextInt();
			while (!serviceUser.isValidAssetId(assetId)) {
				System.err.println("Should contain only 4 digit number");
				assetId = scanner.nextInt();
			}
			int validateAssetId = serviceUser.checkAssetId(assetId);
			if (validateAssetId == 1) {
				int employeeId = inputEmployeeId();
				AssetAllocationBean assetAllocation = new AssetAllocationBean();
				assetAllocation.setAssetId(assetId);
				assetAllocation.setEmpNo(employeeId);
				int allocationId = serviceUser.raiseRequest(assetAllocation);
				logger.info("The Request has been raised with Requisition Id: "
						+ allocationId);
				System.out
						.println("The Request has been raised with Requisition Id: "
								+ allocationId);
			} else {
				System.out
						.println("Given AssetId is Not Available in the Inventory");
			}
		} catch (Exception e) {
			scanner.next();
			System.err
					.println("Invalid Entry.\nPlease Enter a numeric value\n");
			AssetClient.inputRequiredAssetId();
		}
	}

	// take employee id to make request
	public static int inputEmployeeId() {

		try {
			System.out.println("Enter the Employee Id");
			int employeeId = scanner.nextInt();
			while (!serviceUser.isValidEmployeeId(employeeId)) {
				System.err.println("Should contain only 5 digit number");
				employeeId = scanner.nextInt();
			}
			// To check whether the entered employeeId is valid or not
			int validateEmployeeId = serviceUser.checkEmployeeId(employeeId);
			// AssetAllocationBean assetAllocation=new
			// AssetAllocationBean(assetId, employeeId);
			if (validateEmployeeId == 1) {
				// System.out.println();
				int checkEmployee = serviceUser.checkEmployee(employeeId);
				if (checkEmployee == 1) {
					return employeeId;
				} else {
					System.out
							.println("Given EmployeeId does Not Match with the MANAGER.");
				}
			} else {
				System.out.println("Given EmployeeId is does Not Exist.");
			}
		} catch (Exception e) {
			scanner.next();
			System.err
					.println("Invalid Entry.\nPlease Enter a numeric value\n");
			AssetClient.inputEmployeeId();
		}
		return 0;
	}

	// take requisition id as input
	public static int inputRequisitionId() {

		try {

			int requisitionId = scanner.nextInt();
			while (!serviceUser.isValidRequisitionId(requisitionId)) {
				System.err.println("Should contain start with 6000 number");
				requisitionId = scanner.nextInt();
			}
			return requisitionId;
		} catch (Exception e) {
			scanner.next();
			System.err
					.println("Invalid Entry.\nPlease Enter a numeric value\n");
			AssetClient.inputRequisitionId();
		}
		return 0;
	}

	// take quantity as input
	public static int inputQuantity() {

		try {
			int quantityValue = scanner.nextInt();

			while (!serviceUser.isValidQuantity(quantityValue)) {
				System.err.println("Should contain only two number");
				quantityValue = scanner.nextInt();
			}
			return quantityValue;
		} catch (Exception e) {
			scanner.next();
			System.err
					.println("Invalid Entry.\nPlease Enter a numeric value\n");
			AssetClient.inputQuantity();
		}
		return 0;
	}

	// input assetid to update
	public static int inputAssetIdToUpdate() {

		try {
			int assetId = scanner.nextInt();
			while (!serviceUser.isValidAssetId(assetId)) {
				System.err.println("Should contain only update number");
				assetId = scanner.nextInt();
			}
			return assetId;
		} catch (Exception e) {
			scanner.next();
			System.err
					.println("Invalid Entry.\nPlease Enter a numeric value\n");
			AssetClient.inputAssetIdToUpdate();
		}
		return 0;
	}

	// input of options
	public static int inputOptions() {

		String optionString = scanner.next();
		while (!serviceUser.isValidOption(optionString)) {
			System.out.println("asd");
			System.err.println("Should contain only a number");
			System.out.println("qwe");
			if (serviceUser.isValidOption(optionString) == true) {
				break;
			} else {
				optionString = scanner.nextLine();
			}
		}
		int option = Integer.parseInt(optionString);
		return option;

	}
}
