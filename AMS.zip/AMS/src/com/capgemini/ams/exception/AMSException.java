package com.capgemini.ams.exception;

public class AMSException extends Exception {
	private static final long serialVersionUID = 12121212L;

	public AMSException(String message) {
		super(message);
	}
}