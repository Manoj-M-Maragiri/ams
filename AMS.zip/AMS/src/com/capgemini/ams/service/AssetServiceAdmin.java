/***********************************Author Name:Manoj M Maragiri*********Emp Id : 155246******************************************/
/*The AssetServiceAdmin contains the implementation of the methods that are being used by the Admin
 *and performs the required operations that are needed by the Admin. It also contains the 
 *validations of the input taken from the Admin.
*/

package com.capgemini.ams.service;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.ams.bean.AssetAllocationBean;
import com.capgemini.ams.bean.AssetDetailsBean;
import com.capgemini.ams.dao.AssetDAOAdmin;
import com.capgemini.ams.dao.IAssetDAOAdmin;
import com.capgemini.ams.exception.AMSException;

public class AssetServiceAdmin implements IAssetServiceAdmin {

	IAssetDAOAdmin assetdaoAdmin=null;
	
	public int addAssetDetails(AssetDetailsBean assetDetails,int status) throws AMSException{
		
		assetdaoAdmin=new AssetDAOAdmin();
		
		return assetdaoAdmin.addAssetDetails(assetDetails,status);
	}


	public ArrayList<AssetDetailsBean> assetInInventory() throws AMSException{
	
		assetdaoAdmin=new AssetDAOAdmin();
		
		return assetdaoAdmin.assetInInventory();
	}
	
	
	public int updateAssetName(AssetDetailsBean assetNameDetails) throws AMSException{
		
		assetdaoAdmin=new AssetDAOAdmin();
		
		return assetdaoAdmin.updateAssetName(assetNameDetails);
	}
	
	
	public int updateAssetDescription(AssetDetailsBean assetDescriptionDetails) throws AMSException{
		
		assetdaoAdmin=new AssetDAOAdmin();
		
		return assetdaoAdmin.updateAssetDescription(assetDescriptionDetails);
	}
	
	
	public int updateAssetQuantity(AssetDetailsBean assetQuantityDetails) throws AMSException{
		
		assetdaoAdmin=new AssetDAOAdmin();
		
		return assetdaoAdmin.updateAssetQuantity(assetQuantityDetails);
	}

	
	public int updateAssetQuantity(int assetId,int newAssetStatus) throws AMSException{
		
		assetdaoAdmin=new AssetDAOAdmin();
		
		return assetdaoAdmin.updateAssetStatus(assetId,newAssetStatus);
	}
	
	
	public int approveRequest(AssetAllocationBean assetAllocation)throws AMSException {
		
		assetdaoAdmin=new AssetDAOAdmin();
		
		return assetdaoAdmin.approveRequest(assetAllocation);
	}
	
	
	public ArrayList<AssetAllocationBean> displayAllocatedAssets() throws AMSException{
		
		assetdaoAdmin=new AssetDAOAdmin();
		
		return assetdaoAdmin.displayAllocatedAssets();
	}
	
	
	public ArrayList<AssetAllocationBean> displayUnallocatedAssets() throws AMSException{
		
		assetdaoAdmin=new AssetDAOAdmin();
		
		return assetdaoAdmin.displayUnallocatedAssets();
	}


	public ArrayList<AssetAllocationBean> displayUnapprovedAssets() throws AMSException {

		assetdaoAdmin=new AssetDAOAdmin();
		
		return assetdaoAdmin.displayUnapprovedAssets();
	}


	public boolean isValidString(String string) {
		Pattern pattern = Pattern.compile("[A-Za-z0-9 .,(){}[]/?&!@#$%*+-_]{5,25}");
		Matcher matcher = pattern.matcher(string);
		return matcher.matches();
	}

}
