package com.capgemini.ams.service;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.ams.bean.AssetAllocationBean;
import com.capgemini.ams.bean.AssetDetailsBean;
import com.capgemini.ams.bean.UserMasterBean;
import com.capgemini.ams.dao.AssetDAOUser;
import com.capgemini.ams.dao.IAssetDAOUser;
import com.capgemini.ams.exception.AMSException;

public class AssetServiceUser implements IAssetServiceUser{
	
	IAssetDAOUser assetdaoUser=null;
	public int authenticateUser(UserMasterBean userMaster) throws AMSException {
		
		assetdaoUser=new AssetDAOUser();
		
		return assetdaoUser.authenticateUser(userMaster);
		
	}
	
	
	public HashMap<Integer, String> displayAssetDetails() throws AMSException {
		
		assetdaoUser=new AssetDAOUser();
		
		return assetdaoUser.displayAssetDetails();
	}
	
	public int raiseRequest(AssetAllocationBean assetAllocation) throws AMSException{
		
		assetdaoUser=new AssetDAOUser();
		
		return assetdaoUser.raiseRequest(assetAllocation);
	}
	
	
	public int checkAssetId(int assetId) throws AMSException{
		
		assetdaoUser=new AssetDAOUser();
		
		return assetdaoUser.checkAssetId(assetId);
		
	}
	
	
	public int checkEmployeeId(int employeeId) throws AMSException{
		
		assetdaoUser=new AssetDAOUser();
		
		return assetdaoUser.checkEmployeeId(employeeId);
		
	}


	public String viewStatus(int requisitionId) throws AMSException{
		
		assetdaoUser=new AssetDAOUser();
		
		return assetdaoUser.viewStatus(requisitionId);
		
	}


	public int checkRequisitionId(int requisitionId) throws AMSException {
		
		assetdaoUser=new AssetDAOUser();
		
		return assetdaoUser.checkRequisitionId(requisitionId);
	}
	
	public boolean isValidUserId(String userId) {
		
		Pattern pattern = Pattern.compile("[0-9]{6,9}");
		Matcher matcher = pattern.matcher(userId);
		return matcher.matches();

	} 
	
	public boolean isValidAssetId(int assetId) {
		
		Pattern pattern = Pattern.compile("[0-9]{4}");
		Matcher matcher = pattern.matcher(Integer.toString(assetId));
		return matcher.matches();

	}


	public boolean isValidEmployeeId(int employeeId) {
		
		Pattern pattern = Pattern.compile("[0-9]{5}");
		Matcher matcher = pattern.matcher(Integer.toString(employeeId));
		return matcher.matches();
	} 
	
	public boolean isValidRequisitionId(int requisitionId) {
		
		Pattern pattern = Pattern.compile("[0-9]{4}");
		Matcher matcher = pattern.matcher(Integer.toString(requisitionId));
		return matcher.matches();
	} 
}
