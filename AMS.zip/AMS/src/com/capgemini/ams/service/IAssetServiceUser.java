package com.capgemini.ams.service;



import java.util.HashMap;

import com.capgemini.ams.bean.AssetAllocationBean;
import com.capgemini.ams.bean.AssetDetailsBean;
import com.capgemini.ams.bean.UserMasterBean;
import com.capgemini.ams.exception.AMSException;

public interface IAssetServiceUser {
	
	public abstract int authenticateUser(UserMasterBean userMaster) throws AMSException;

	public abstract HashMap<Integer,String> displayAssetDetails() throws AMSException;
	
	public abstract int raiseRequest(AssetAllocationBean assetAllocation) throws AMSException;
	
	public abstract int checkAssetId(int assetId) throws AMSException;
	
	public abstract int checkEmployeeId(int employeeId) throws AMSException;
	
	public abstract String viewStatus(int requisitionId) throws AMSException;
	
	public abstract int checkRequisitionId(int requisitionId) throws AMSException;
	
	public abstract boolean isValidUserId(String userId) ;
	
	public abstract boolean isValidAssetId(int assetId) ;
	
	public abstract boolean isValidEmployeeId(int employeeId) ;
	
	public abstract boolean isValidRequisitionId(int requisitionId) ;
	
}