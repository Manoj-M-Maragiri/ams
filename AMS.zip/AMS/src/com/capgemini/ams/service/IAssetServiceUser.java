/***********************************Author Name:Manoj M Maragiri*********Emp Id : 155246******************************************/
/*The IAssetServiceUser contains the abstract methods that are being used by the user
 * for performing the required operations that are needed by the user
*/
package com.capgemini.ams.service;



import java.util.HashMap;

import com.capgemini.ams.bean.AssetAllocationBean;
import com.capgemini.ams.bean.AssetDetailsBean;
import com.capgemini.ams.bean.UserMasterBean;
import com.capgemini.ams.exception.AMSException;

public interface IAssetServiceUser {
	
	public abstract int authenticateUser(UserMasterBean userMaster) throws AMSException;

	public abstract HashMap<Integer,String> displayAssetDetails() throws AMSException;
	
	public abstract int raiseRequest(AssetAllocationBean assetAllocation) throws AMSException;
	
	public abstract int checkAssetId(int assetId) throws AMSException;
	
	public abstract int checkEmployeeId(int employeeId) throws AMSException;
	
	public abstract int checkEmployee(int employeeId) throws AMSException;
	
	public abstract String viewStatus(AssetAllocationBean assetAllocation) throws AMSException;
	
	public abstract int checkRequisitionId(int requisitionId) throws AMSException;
	
	public abstract boolean isValidUserId(String userId) ;
	
	public abstract boolean isValidAssetId(int assetId) ;
	
	public abstract boolean isValidEmployeeId(int employeeId) ;
	
	public abstract boolean isValidRequisitionId(int requisitionId) ;

	public abstract boolean isValidQuantity(int quantityValue);

	public abstract boolean isValidOption(String option);

	public abstract boolean isValidPassword(String password);

	
}