package com.capgemini.ams.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

import com.capgemini.ams.bean.AssetAllocationBean;
import com.capgemini.ams.bean.AssetDetailsBean;
import com.capgemini.ams.bean.UserMasterBean;
import com.capgemini.ams.exception.AMSException;
import com.capgemini.ams.ui.AssetClient;

public class AssetDAOUser implements IAssetDAOUser{
	
	int flag = 0;
    Connection connection=null;

    //To validate the user
	public int authenticateUser(UserMasterBean userMaster) throws AMSException {
		
		 try {
			 	connection = DBUtil.establishConnection();
		        PreparedStatement preparedStatement = connection.prepareStatement(IQueryMapper.AUTHENTICATE_USER);
		        preparedStatement.setString(1,userMaster.getUserId());
		        ResultSet results = preparedStatement.executeQuery();
		        
		        
		        while (results.next()) {
		        String userid = results.getString(1);
		        String passwrd =  results.getString(2);
		        String usertype = results.getString(3);
		      
		           if ((userMaster.getUserId().equals(userid)) && (userMaster.getPassword().equals(passwrd)) && (usertype.equals("M"))) {
		              flag = 1;
		              return flag;
		           }
		           else if ((userMaster.getUserId().equals(userid)) && (userMaster.getPassword().equals(passwrd))&& (usertype.equals("A"))) {
			          flag = 2;
			          return flag;
			       }
		      }
		        
		      results.close();
		      }catch(SQLException e) {
		    	throw new AMSException("User Not Authenticated");
		    }
		return flag;
	}

	//to display the assetdetails for the manager
	public HashMap<Integer,String> displayAssetDetails() throws AMSException{
		
	 HashMap<Integer,String> assetMap=new HashMap<Integer,String>();
	 try {
			connection = DBUtil.establishConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(IQueryMapper.DISPLAY_ASSETDETAILS);
			ResultSet results = preparedStatement.executeQuery();
		
			while(results.next()){
				int assetId=results.getInt(1);
				String assetName=results.getString(2);
				
				assetMap.put(assetId,assetName);
			}
			
			
		} catch (SQLException e) {
			throw new AMSException("Does not contain any Asset");
		}
		
		return assetMap;
	 }
	 
	//Raise a request for the asset
	public int raiseRequest(AssetAllocationBean assetAllocation) throws AMSException{
		
		int status=0;
		int allocationId=0;
		try {
			connection = DBUtil.establishConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(IQueryMapper.REQUEST_QUERY);
			preparedStatement.setInt(1, assetAllocation.getAssetId());
			preparedStatement.setInt(2, assetAllocation.getEmpNo());
			status = preparedStatement.executeUpdate();
			
			if(status==1){
				PreparedStatement preparedstatement = connection.prepareStatement(IQueryMapper.ALLOCATIONID_VALUE);
				ResultSet results = preparedstatement.executeQuery();
				results.next();
				allocationId = results.getInt(1);
			}
			
			
		} catch (SQLException e) {
			throw new AMSException("Request for Asset cannot be created");
		}
		
		
		return allocationId;
	}
	
	//Check whether the assetid entered by manager is valid
	public int checkAssetId(int assetId) throws AMSException{
		
		int status=0;
		try {
			connection = DBUtil.establishConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(IQueryMapper.ASSETID_QUERY);
			preparedStatement.setInt(1, assetId);
			ResultSet results = preparedStatement.executeQuery();
			
			while(results.next()){
				int assetid=results.getInt(1);
				if(assetId==assetid){
					status=1;	
				}
				else{
					status=0;
				}
			}
			
			
		} catch (SQLException e) {
			throw new AMSException("Entered AssetId is INVALID ");
		}
		
		return status;
	}
	
	
	//Check whether the employeeid entered by manager is valid
		public int checkEmployeeId(int employeeId) throws AMSException{
			
			int status=0;
			try {
				connection = DBUtil.establishConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(IQueryMapper.EMPLOYEEID_QUERY);
				preparedStatement.setInt(1, employeeId);
				ResultSet results = preparedStatement.executeQuery();
				
				while(results.next()){
					int employeeid=results.getInt(1);
					
					if(employeeId==employeeid){
						status=1;	
					}
					else{
						status=0;
					}
				}
				
				
			} catch (SQLException e) {
				throw new AMSException("Entered EmployeeId is INVALID ");
			}
			
			return status;
		}
		
		
	//To get the status of asset based on Allocation Id
	public String viewStatus(int requisitionId) throws AMSException{
		
		String status=null;
		
		try {
			connection = DBUtil.establishConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(IQueryMapper.STATUS_QUERY);
			preparedStatement.setInt(1, requisitionId);
			ResultSet results = preparedStatement.executeQuery();
			
			while(results.next()){
				status=results.getString(1);
			}
			
			
		} catch (SQLException e) {
			throw new AMSException("RequisitionId not available");
		}
		
		return status;
	}


	public int checkRequisitionId(int requisitionId) throws AMSException {

		int status=0;
		try {
			connection = DBUtil.establishConnection();
			PreparedStatement preparedStatement = connection.prepareStatement(IQueryMapper.REQUSITIONID_QUERY);
			preparedStatement.setInt(1, requisitionId);
			ResultSet results = preparedStatement.executeQuery();
			
			while(results.next()){
				int assetid=results.getInt(1);
				if(requisitionId==assetid){
					status=1;	
				}
				else{
					status=0;
				}
			}
			
			
		} catch (SQLException e) {
			throw new AMSException("Entered AssetId is INVALID ");
		}
		
		return status;
	}
	
	
}
