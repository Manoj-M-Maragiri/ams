/***********************************Author Name:Manoj M Maragiri******Emp Id : 155246******************************************/
/*The IAssetDAOUser interface contains the abstract methods of the AssetDAOUser 
 * which is called to perform the operations that modification to the database 
 * and retrieve data and display in the AssetClient class
*/
package com.capgemini.ams.dao;

import java.util.HashMap;

import com.capgemini.ams.bean.AssetAllocationBean;
import com.capgemini.ams.bean.AssetDetailsBean;
import com.capgemini.ams.bean.UserMasterBean;
import com.capgemini.ams.exception.AMSException;

public interface IAssetDAOUser {
	

	public abstract int authenticateUser(UserMasterBean userMaster) throws AMSException;

	public abstract HashMap<Integer,String> displayAssetDetails() throws AMSException;
	
	public abstract int raiseRequest(AssetAllocationBean assetAllocation) throws AMSException;
	
	public abstract int checkAssetId(int assetId) throws AMSException;
	
	public abstract int checkEmployeeId(int employeeId) throws AMSException;
	
	public abstract int checkEmployee(int employeeId) throws AMSException;
	
	public abstract String viewStatus(AssetAllocationBean assetAllocation) throws AMSException;
	
	public abstract int checkRequisitionId(int requisitionId) throws AMSException;

	
	
}