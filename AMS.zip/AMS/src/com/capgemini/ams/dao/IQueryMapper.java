package com.capgemini.ams.dao;

public interface IQueryMapper {
	//Manager()
	public final String AUTHENTICATE_USER="SELECT UserId,UserPassword,UserType FROM User_Master WHERE UserId=?";
	
	public final String DISPLAY_ASSETDETAILS="SELECT AssetId,AssetName FROM Asset";
	
	public final String REQUEST_QUERY="INSERT INTO Asset_Allocation values(sq_allocationid.NEXTVAL,?,?,SYSDATE,'null','Pending')";
	
	public final String ASSETID_QUERY="SELECT AssetId FROM Asset WHERE AssetId=?";
	
	public final String EMPLOYEEID_QUERY="SELECT Empno FROM Employee WHERE Empno=?";
	
	public final String ALLOCATIONID_VALUE="SELECT sq_allocationid.CURRVAL FROM DUAL";
	
	public final String STATUS_QUERY="SELECT Asset_status FROM Asset_Allocation WHERE AllocationId=?";
	
	public final String REQUSITIONID_QUERY="SELECT AllocationId FROM Asset_Allocation WHERE AllocationId=?";
	
	
	//Admin()
	public final String INSERT_DETAILS="INSERT INTO Asset VALUES(seq_assetId.NEXTVAL,?,?,?,?)";
	
	public final String DISPLAYASSET_DETAILS="SELECT AssetId,AssetName,AssetDes,Quantity,Status FROM Asset";
	
	public final String UPDATE_ASSETNAME_DETAILS="UPDATE Asset SET AssetName=? WHERE AssetId=?";
	
	public final String UPDATE_ASSETDESCRIPTION_DETAILS="UPDATE Asset SET AssetDes=? WHERE AssetId=?";
	
	public final String UPDATE_ASSETQUANTITY_DETAILS="UPDATE Asset SET Quantity=? WHERE AssetId=?";
	
	public final String UPDATE_ASSETSTATUS_DETAILS="UPDATE Asset SET Status=? WHERE AssetId=?";
	
	public final String APPROVE_REQ="UPDATE Asset_Allocation SET Asset_status='Approved', Release_date=SYSDATE+2 WHERE AllocationId=?";
	
	public final String REDUCE_QUANTITY_ON_APPROVAL="UPDATE Asset SET Quantity=Quantity-1 WHERE AssetId=(Select AssetId FROM Asset_Allocation WHERE AllocationId=?";
	
	public final String DISPLAY_UNAPPROVED_DETAILS="SELECT AllocationId,AssetId,Empno,Allocation_date,Release_date FROM Asset_Allocation WHERE Asset_status='Pending'";
	
	public final String DISPLAYALLOCATED_DETAILS="SELECT AllocationId,AssetId,Empno,Allocation_date,Release_date FROM Asset_Allocation WHERE Asset_status='Assigned'";
	
	public final String DISPLAYUNALLOCATED_DETAILS="SELECT AllocationId,AssetId,Empno,Allocation_date,Release_date FROM Asset_Allocation WHERE Asset_status='Pending' or Asset_status='Rejected'";
	
}