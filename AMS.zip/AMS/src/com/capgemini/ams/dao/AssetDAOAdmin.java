package com.capgemini.ams.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.ams.bean.AssetAllocationBean;
import com.capgemini.ams.bean.AssetDetailsBean;
import com.capgemini.ams.exception.AMSException;

public class AssetDAOAdmin implements IAssetDAOAdmin{
	
	int flag = 0;
    Connection connection=null;
    String assetStatus=null;
  //To add asset Details
  	public int addAssetDetails(AssetDetailsBean assetDetails,int status) throws AMSException{
  		
  		
  		if(status==1){
  			assetStatus="Available";
  		}
  		else if(status==2){
  			assetStatus="Not Available";
  		}
  		try {
  			connection = DBUtil.establishConnection();
  			PreparedStatement preparedStatement = connection.prepareStatement(IQueryMapper.INSERT_DETAILS);
  			preparedStatement.setString(1, assetDetails.getAssetName());
  			preparedStatement.setString(2, assetDetails.getAssetDescription());
  			preparedStatement.setInt(3, assetDetails.getQuantity());
  			preparedStatement.setString(4, assetStatus);
  			int insertStatus=preparedStatement.executeUpdate();
  			
  			if(insertStatus==1){
  				flag=1;
  			}else{
  				flag=0;
  			}
  		
  		} catch (SQLException e) {
  			throw new AMSException("Asset Details Not inserted");
  		}
  		return flag;
  	}

  	
  	public int approveRequest(AssetAllocationBean assetAllocation) throws AMSException {
		try {
  			connection = DBUtil.establishConnection();
  			PreparedStatement preparedStatement = connection.prepareStatement(IQueryMapper.APPROVE_REQ);
  			preparedStatement.setInt(1, assetAllocation.getAllocationId());
  			
  			int approveStatus=preparedStatement.executeUpdate();
  			if(approveStatus==1){
  				flag=1;
  				PreparedStatement preparedstatement = connection.prepareStatement(IQueryMapper.REDUCE_QUANTITY_ON_APPROVAL);
  				preparedStatement.setInt(1, assetAllocation.getAllocationId());
  				ResultSet results=preparedstatement.executeQuery();
  				
  			}else{
  				flag=0;
  			}
  		} catch (SQLException e) {
  			throw new AMSException("Asset not Approved");
  		}
  		
		return flag;
	}
  	
  	
  	//To display asset list
	public ArrayList<AssetDetailsBean> assetInInventory() throws AMSException{
		
  		ArrayList<AssetDetailsBean> assetList= new ArrayList<AssetDetailsBean>();
  		
  		
  		try {
  			connection = DBUtil.establishConnection();
  			PreparedStatement preparedStatement = connection.prepareStatement(IQueryMapper.DISPLAYASSET_DETAILS);
  			ResultSet results = preparedStatement.executeQuery();
  			
			while(results.next()){
				int assetId=results.getInt(1);
				String assetName=results.getString(2);
				String assetDescription=results.getString(3);
				int assetQuantity=results.getInt(4);
				String assetStatus=results.getString(5);
				
				AssetDetailsBean assetDetails=new AssetDetailsBean(assetId, assetName, assetDescription, assetQuantity, assetStatus);
				assetList.add(assetDetails);
			}
			
  		} catch (SQLException e) {
  			throw new AMSException("No Details about Assets");
  		}
		
		
		return assetList;
	}
	
	
  	//To update asset name
  	public int updateAssetName(AssetDetailsBean assetNameDetails) throws AMSException {
		
  		try {
  			connection = DBUtil.establishConnection();
  			PreparedStatement preparedStatement = connection.prepareStatement(IQueryMapper.UPDATE_ASSETNAME_DETAILS);
  			preparedStatement.setString(1, assetNameDetails.getAssetName());
  			preparedStatement.setInt(2, assetNameDetails.getAssetId());
  			
  			int updateNameStatus=preparedStatement.executeUpdate();
  			if(updateNameStatus==1){
  				flag=1;
  			}else{
  				flag=0;
  			}
  		} catch (SQLException e) {
  			throw new AMSException("Asset Name not updated");
  		}
		return flag;
	}
  	
  	
  //To update asset description
  	public int updateAssetDescription(AssetDetailsBean assetDescriptionDetails) throws AMSException{
		

  		try {
  			connection = DBUtil.establishConnection();
  			PreparedStatement preparedStatement = connection.prepareStatement(IQueryMapper.UPDATE_ASSETDESCRIPTION_DETAILS);
  			preparedStatement.setString(1, assetDescriptionDetails.getAssetDescription());
  			preparedStatement.setInt(2, assetDescriptionDetails.getAssetId());
  			
  			int updateDescriptionStatus=preparedStatement.executeUpdate();
  			if(updateDescriptionStatus==1){
  				flag=1;
  			}else{
  				flag=0;
  			}
  		} catch (SQLException e) {
  			throw new AMSException("Asset Description not updated");
  		}
		
		return flag;
	}
  	
  	
  //To update asset quantity
  	public int updateAssetQuantity(AssetDetailsBean assetQuantityDetails) throws AMSException {
		
  		try {
  			connection = DBUtil.establishConnection();
  			PreparedStatement preparedStatement = connection.prepareStatement(IQueryMapper.UPDATE_ASSETQUANTITY_DETAILS);
  			preparedStatement.setString(1, assetQuantityDetails.getAssetDescription());
  			preparedStatement.setInt(2, assetQuantityDetails.getAssetId());
  			
  			int updateQuantityStatus=preparedStatement.executeUpdate();
  			if(updateQuantityStatus==1){
  				flag=1;
  			}else{
  				flag=0;
  			}
  		} catch (SQLException e) {
  			throw new AMSException("Asset Quantity not updated");
  		}
  		
		return flag;
	}
  	
  	
  //To update asset status
  	public int updateAssetStatus(int assetId,int newAssetStatus) throws AMSException{
		
  		if(newAssetStatus==1){
  			assetStatus="Available";
  		}
  		else if(newAssetStatus==2){
  			assetStatus="Not Available";
  		}
  		try {
  			connection = DBUtil.establishConnection();
  			PreparedStatement preparedStatement = connection.prepareStatement(IQueryMapper.UPDATE_ASSETSTATUS_DETAILS);
  			preparedStatement.setString(1, assetStatus);
  			preparedStatement.setInt(2, assetId);
  			
  			int updateQuantityStatus=preparedStatement.executeUpdate();
  			if(updateQuantityStatus==1){
  				flag=1;
  			}else{
  				flag=0;
  			}
  		} catch (SQLException e) {
  			throw new AMSException("Asset Status not updated");
  		}
		
		return flag;
	}
  	
  	
  	//To display the details of allocated assets
  	public ArrayList<AssetAllocationBean> displayAllocatedAssets() throws AMSException{
		
  		ArrayList<AssetAllocationBean> allocatedList= new ArrayList<AssetAllocationBean>();
  		
  		
  		try {
  			connection = DBUtil.establishConnection();
  			PreparedStatement preparedStatement = connection.prepareStatement(IQueryMapper.DISPLAYALLOCATED_DETAILS);
  			ResultSet results = preparedStatement.executeQuery();
  			
			while(results.next()){
				int allocationId=results.getInt(1);
				int assetId=results.getInt(2);
				int empNo=results.getInt(3);
				String allocationDate=results.getString(4);
				String releaseDate=results.getString(5);
				
				AssetAllocationBean assetAllocation= new AssetAllocationBean(allocationId,assetId,empNo,allocationDate,releaseDate);
				allocatedList.add(assetAllocation);
			}
			
  		} catch (SQLException e) {
  			throw new AMSException("No Details about Allocated Assets");
  		}
		
		
		return allocatedList;
	}

  	
  	//to display unallocated asset details
  	public ArrayList<AssetAllocationBean> displayUnallocatedAssets() throws AMSException{
		
  		ArrayList<AssetAllocationBean> unallocatedList= new ArrayList<AssetAllocationBean>();
  		
  		
  		try {
  			connection = DBUtil.establishConnection();
  			PreparedStatement preparedStatement = connection.prepareStatement(IQueryMapper.DISPLAYUNALLOCATED_DETAILS);
  			ResultSet results = preparedStatement.executeQuery();
  			
			while(results.next()){
				int allocationId=results.getInt(1);
				int assetId=results.getInt(2);
				int empNo=results.getInt(3);
				String allocationDate=results.getString(4);
				String releaseDate=results.getString(5);
				
				AssetAllocationBean assetAllocation= new AssetAllocationBean(allocationId,assetId,empNo,allocationDate,releaseDate);
				unallocatedList.add(assetAllocation);
			}
			
  		} catch (SQLException e) {
  			throw new AMSException("No Details about Allocated Assets");
  		}
		
		return unallocatedList;
	}


	public ArrayList<AssetAllocationBean> displayUnapprovedAssets() throws AMSException {
ArrayList<AssetAllocationBean> unallocatedList= new ArrayList<AssetAllocationBean>();
  		
  		
  		try {
  			connection = DBUtil.establishConnection();
  			PreparedStatement preparedStatement = connection.prepareStatement(IQueryMapper.DISPLAY_UNAPPROVED_DETAILS);
  			ResultSet results = preparedStatement.executeQuery();
  			
			while(results.next()){
				int allocationId=results.getInt(1);
				int assetId=results.getInt(2);
				int empNo=results.getInt(3);
				String allocationDate=results.getString(4);
				String releaseDate=results.getString(5);
				
				AssetAllocationBean assetAllocation= new AssetAllocationBean(allocationId,assetId,empNo,allocationDate,releaseDate);
				unallocatedList.add(assetAllocation);
			}
			
  		} catch (SQLException e) {
  			throw new AMSException("No Details about Allocated Assets");
  		}
		
		return unallocatedList;
	}

  	
	

	
	
}
